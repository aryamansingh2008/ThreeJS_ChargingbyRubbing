p=new Array;
var pcharge;
var ncharge;
var count;
var object;
var surface;
var k;
var p1,p2,p3,n1,n2,n3;
var charge;
var lm;
var tableindex;
var helpContent;
var infoContent;
var t1,t2;

function initialiseHelp()
{
	helpContent="";
    helpContent = helpContent + "<h2>Experiment charging by rubbing help</h2>";
    helpContent = helpContent + "<h3>About the experiment</h3>";
    helpContent = helpContent + "<p>Shown the production of electrostatic charge.<p>";
    helpContent = helpContent + "<h3>Animation control for Experiment Mode</h3>";
    helpContent = helpContent + "<p>Select one of the Everyday Materials(Material A)</p>";
    helpContent = helpContent + "<p>Select one of the Rubbing Surfaces(mAterial B).</p>";
	helpContent = helpContent + "<p>When the animation starts, the material A is rubbed against B.</p>";
	helpContent = helpContent + "<p>The Material A is then brought near paper pieces to check whether it is charged or not.</p>";
	helpContent = helpContent + "<p>The charge obtained by the Material A is also shown on the material itself.</p>";
    helpContent = helpContent + "<p>Click on pause button to pause the animation</p>";
    helpContent = helpContent + "<p>Click on Reset button to reset animation</p>";
	helpContent = helpContent + "<h3>Animation control for Learning Mode</h3>";
	helpContent = helpContent + "<p>An Everyday Material is randomly selected.</p>";
    helpContent = helpContent + "<p>A rubbing surface is randomly selected.</p>";
	helpContent = helpContent + "<p>The table is filled with their respective values.</p>";
	helpContent = helpContent + "<p>Select whether electrostatic charge will be produced or not. Help may be taken from the Information Section.</p>";
	helpContent = helpContent + "<p>If the answer is correct, the electrostatic charge production is shown.</p>";
	helpContent = helpContent + "<p>Click on pause button to pause the animation</p>";
    helpContent = helpContent + "<p>Click on Reset button to reset animation</p>";
    infoContent = infoContent + "<h2>Happy Experimenting</h2>";
    PIEupdateHelp(helpContent);
}

function initialiseInfo()
{
    infoContent =  "";
    infoContent = infoContent + "<h2>Experiment charging by rubbing concepts</h2>";
    infoContent = infoContent + "<h3>About the experiment</h3>";
    infoContent = infoContent + "<p>Shown the production of electrostatic charge.</p>";
    infoContent = infoContent + "<p>When two different materials are pressed or rubbed together, the surface of one material will generally steal some electrons from the surface of the other material.</p>";
	infoContent = infoContent + "<p>The material that steals electrons has the stronger affinity for negative charge of the two materials, and that surface will be negatively charged after the materials are separated.</p>";
	infoContent = infoContent + "<p>The outcome of the rubbing can be predicted by the TriboElectric Series :- </p>";
	infoContent = infoContent + "<h3>Glass</h3>";
	infoContent = infoContent + "<h3>Hair</h3>";
	infoContent = infoContent + "<h3>Wool</h3>";
	infoContent = infoContent + "<h3>Silk</h3>";
	infoContent = infoContent + "<h3>Cotton</h3>";
	infoContent = infoContent + "<h3>Wood</h3>";
	infoContent = infoContent + "<h3>Eraser(Rubber)</h3>";
	infoContent = infoContent + "<h3>Ruler(Plastic)</h3>";
	infoContent = infoContent + "<p>A material towards the bottom of the series, when touched to a material near the top of the series, will acquire a more negative charge. The farther away two materials are from each other on the series, the greater the charge transferred. Materials near to each other on the series may not exchange any charge, or may even exchange the opposite of what is implied by the list.</p>";
	infoContent = infoContent + "<p>When glass and wool are rubbed against each other, due to very less difference in electron affinity, no electrons are exchanged and hence both of them remain uncharged.</p>";
	infoContent = infoContent + "<p>Cotton has almost zero tendency to attract or loose electrons, so the rubbing involving cotton never leads to production of electrostatic charge.</p>";
	

    PIEupdateInfo(infoContent);
}

function resettable()
{
	PIEtableSelect("Experimental Data");
	
	PIEupdateTableCell(3,0,"-");
	PIEupdateTableCell(3,1,"-");
	PIEupdateTableCell(3,2,"-");
	
	PIEupdateTableCell(4,0,"-");
	PIEupdateTableCell(4,1,"-");
	PIEupdateTableCell(4,2,"-");
	
	PIEupdateTableCell(5,0,"-");
	PIEupdateTableCell(5,1,"-");
	PIEupdateTableCell(5,2,"-");
	
	PIEupdateTableCell(2,0,"-");
	PIEupdateTableCell(2,1,"-");
	PIEupdateTableCell(2,2,"-");

	
	PIEtableSelect("Experimental Data.");
	PIEupdateTableCell(2,0,"-");
	PIEupdateTableCell(2,1,"-");
	PIEupdateTableCell(2,2,"-");
}

function appendtable()
{
	
	if(tableindex!=6)
	{
		PIEtableSelect("Experimental Data");
		if(object==ruler)
		PIEupdateTableCell(tableindex,0,"Ruler");
		if(object==eraser)
		PIEupdateTableCell(tableindex,0,"Eraser");
		if(object==wood)
		PIEupdateTableCell(tableindex,0,"Wood");
		if(object==glass)
		PIEupdateTableCell(tableindex,0,"Glass");
		
		if(surface==wool)
		PIEupdateTableCell(tableindex,1,"Wool");
		if(surface==silk)
		PIEupdateTableCell(tableindex,1,"Silk");
		if(surface==hair)
		PIEupdateTableCell(tableindex,1,"Hair");
		if(surface==cotton)
		PIEupdateTableCell(tableindex,1,"Cotton");
		
		var x;
		if(charge==0)
			x="Not charged";
		if(charge==1)
			x="Positive";
		if(charge==-1)
			x="Negative";
		
		PIEupdateTableCell(tableindex,2,x);
		tableindex++;
	}
	else
	{
		alert("Reset Experiment to Continue with the Experiment");
		tableindex=7;
		PIEstopAnimation();
	}
}

function appendtable2()
{
		PIEtableSelect("Experimental Data.");
	
		if(object==ruler)
		PIEupdateTableCell(2,0,"Ruler");
		if(object==eraser)
		PIEupdateTableCell(2,0,"Eraser");
		if(object==wood)
		PIEupdateTableCell(2,0,"Wood");
		if(object==glass)
		PIEupdateTableCell(2,0,"Glass");
		
		if(surface==wool)
		PIEupdateTableCell(2,1,"Wool");
		if(surface==silk)
		PIEupdateTableCell(2,1,"Silk");
		if(surface==hair)
		PIEupdateTableCell(2,1,"Hair");
		if(surface==cotton)
		PIEupdateTableCell(2,1,"Cotton");
}

function addTable()
{
	var table=new THREE.Mesh(new THREE.CubeGeometry(25,0.5,8),new THREE.MeshBasicMaterial({map:THREE.ImageUtils.loadTexture("wood.jpg")}));
	table.position.y=-2.5;
	table.rotation.x+=Math.PI/6;
	PIEaddElement(table);
	
	
	var leg1=new THREE.Mesh(new THREE.CubeGeometry(0.5,4.5,0.5),new THREE.MeshBasicMaterial({map:THREE.ImageUtils.loadTexture("wood.jpg")}));
	leg1.position.set(-12.5,-5,0);
	PIEaddElement(leg1);
	
	var leg2=new THREE.Mesh(new THREE.CubeGeometry(0.5,7,0.5),new THREE.MeshBasicMaterial({map:THREE.ImageUtils.loadTexture("wood.jpg")}));
	leg2.position.set(-11.5,-5,-2);
	PIEaddElement(leg2);

	var leg3=new THREE.Mesh(new THREE.CubeGeometry(0.5,7,0.5),new THREE.MeshBasicMaterial({map:THREE.ImageUtils.loadTexture("wood.jpg")}));
	leg3.position.set(+11.5,-5,-2);
	PIEaddElement(leg3);
	
	var leg4=new THREE.Mesh(new THREE.CubeGeometry(0.5,4.5,0.5),new THREE.MeshBasicMaterial({map:THREE.ImageUtils.loadTexture("wood.jpg")}));
	leg4.position.set(+12.5,-5,0);
	PIEaddElement(leg4);
}

function PIEcreateTable(i,n,g,d)
{
	var c;var b;var m;var f;var a;var h;var l;var k;var j;var e;PIEtableChangeHandlers.push(null);PIEtableNames.push(i);PIEtableRows.push(new Array(0));PIEtableData.push(new Array(0));PIEtableChangeHandlers.push(null);PIEcurrentTable=PIEtableNames.length-1;c=document.createElement("div");c.draggable=true;c.addEventListener("dragstart",PIEtableDragStart,false);c.id="mytable";c.style.border="2px solid white";c.style.borderRadius="10px";c.style.display="inline-block";c.style.position="absolute";c.style.top="60px";c.style.color="white";document.body.appendChild(c);b=document.createElement("div");b.style.display="inline-block";b.style.width="100%";b.style.padding="0px";c.appendChild(b);m=document.createElement("p");m.style.display="inline-block";m.style.width="100%";m.style.margin="auto";m.style.border="2 px solid white";m.style.borderRadius="10px";m.style.backgroundColor="#0020AA";b.appendChild(m);f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";a=document.createElement("img");a.src="../PIE/images/TableAdd.png";a.alt="add";a.height="16";a.width="16";a.style.display="inline";f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";a=document.createElement("img");a.src="../PIE/images/TableDelete.png";a.alt="delete";a.height="16";a.width="16";a.style.display="inline";a=document.createElement("span");a.style.padding="5px";a.style.margin="auto";a.style.align="center";a.innerHTML="<b>"+i+"</b>";m.appendChild(a);f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";f.style.align="right";f.addEventListener("click",PIEtoggleTable,false);m.appendChild(f);a=document.createElement("img");a.src="../PIE/images/TableFold.png";a.alt="delete";a.height="16";a.width="16";a.style.display="inline";f.appendChild(a);a=document.createElement("div");h=document.createElement("table");h.style.display="inline-block";h.style.border="1px solid white";h.style.borderRadius="10px";h.style.padding="0px";h.style.backgroundColor="#0040BB";PIEtables.push(h);a.appendChild(h);c.appendChild(a);for(j=0;j<n;j++){for(e=0;e<g;e++){if(j==0){k=PIEcreateTableCell(j,e,d)}else{k=PIEcreateTableCell(j,e,false)}}}PIEupdateTable(PIEtables[PIEcurrentTable])
}

function PIEcreateTable1(i,n,g,d)
{
	var c;var b;var m;var f;var a;var h;var l;var k;var j;var e;PIEtableChangeHandlers.push(null);PIEtableNames.push(i);PIEtableRows.push(new Array(0));PIEtableData.push(new Array(0));PIEtableChangeHandlers.push(null);PIEcurrentTable=PIEtableNames.length-1;c=document.createElement("div");c.draggable=true;c.addEventListener("dragstart",PIEtableDragStart,false);c.id="mytable2";c.style.border="2px solid white";c.style.borderRadius="10px";c.style.display="inline-block";c.style.position="absolute";c.style.top="60px";c.style.color="white";document.body.appendChild(c);b=document.createElement("div");b.style.display="inline-block";b.style.width="100%";b.style.padding="0px";c.appendChild(b);m=document.createElement("p");m.style.display="inline-block";m.style.width="100%";m.style.margin="auto";m.style.border="2 px solid white";m.style.borderRadius="10px";m.style.backgroundColor="#0020AA";b.appendChild(m);f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";a=document.createElement("img");a.src="../PIE/images/TableAdd.png";a.alt="add";a.height="16";a.width="16";a.style.display="inline";f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";a=document.createElement("img");a.src="../PIE/images/TableDelete.png";a.alt="delete";a.height="16";a.width="16";a.style.display="inline";a=document.createElement("span");a.style.padding="5px";a.style.margin="auto";a.style.align="center";a.innerHTML="<b>"+i+"</b>";m.appendChild(a);f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";f.style.align="right";f.addEventListener("click",PIEtoggleTable,false);m.appendChild(f);a=document.createElement("img");a.src="../PIE/images/TableFold.png";a.alt="delete";a.height="16";a.width="16";a.style.display="inline";f.appendChild(a);a=document.createElement("div");h=document.createElement("table");h.style.display="inline-block";h.style.border="1px solid white";h.style.borderRadius="10px";h.style.padding="0px";h.style.backgroundColor="#0040BB";PIEtables.push(h);a.appendChild(h);c.appendChild(a);for(j=0;j<n;j++){for(e=0;e<g;e++){if(j==0){k=PIEcreateTableCell(j,e,d)}else{k=PIEcreateTableCell(j,e,false)}}}PIEupdateTable(PIEtables[PIEcurrentTable])
}

function PIEtoggleTable(e)
{
	var g;var c;var a;var h;var f;var d;var b;e=e||window.event;e.defaultPrevented=true;g=null;if(e.target){g=e.target}else{if(e.srcElement){g=e.srcElement}}if(g!=null){if(g.nodeType==3){g=g.parentNode}a=((g.parentNode).parentNode).parentNode;h=a.children;for(d=0;(d<h.length);d++){f=h[d].children;for(b=0;(b<f.length);b++){if(f[b].nodeName=="TABLE"){c=f[b];if(c.style.display=="inline-block"){c.style.display="none"}else{c.style.display="inline-block"}}}}}
}

function addlearning()
{
	var k=-2.2;
	
	plane=new THREE.Mesh(new THREE.PlaneGeometry(6,2,1),new THREE.MeshBasicMaterial({color:"green"}));
	PIEaddElement(plane);
	plane.position.set(-8,5.8+k,-5);
	plane.visible=false;
	
	yes=new THREE.Mesh(new THREE.PlaneGeometry(2.2,1.5,1),new THREE.MeshBasicMaterial({color:"blue"}));
	PIEaddElement(yes);
	yes.position.set(-9.5,3.6+k,-5);
	yes.visible=false;
	
	no=new THREE.Mesh(new THREE.PlaneGeometry(2.2,1.5,1),new THREE.MeshBasicMaterial({color:"red"}));
	PIEaddElement(no);
	no.position.set(-6.5,3.6+k,-5);
	no.visible=false;
	
	 var loader = new THREE.FontLoader();
    loader.load("optimer.json", function(response){
        font = response;
		
		geometry = new THREE.TextGeometry('Is Material \'A\'', {
        	font : font,
            size : 0.5,
            height : 0.02,
        });
		t=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        t.translation = geometry.center();
        plane.add(t);
        t.castShadow=false;
        t.visible=false;
        t.position.set(0,0.3,0.3);
	
		geometry = new THREE.TextGeometry('charged?', {
        	font : font,
            size : 0.5,
            height : 0.02,
        });
		t2=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        t2.translation = geometry.center();
        plane.add(t2);
        t2.castShadow=false;
        t2.visible=false;
        t2.position.set(0,-0.5,0.3);
		
		geometry = new THREE.TextGeometry('Yes', {
        	font : font,
            size : 0.5,
            height : 0.02,
        });
		yestext=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        yestext.translation = geometry.center();
        yes.add(yestext);
        yestext.castShadow=false;
        yestext.visible=false;
        yestext.position.set(0,0,0.3);
		
		geometry = new THREE.TextGeometry('No', {
        	font : font,
            size : 0.5,
            height : 0.02,
        });
		notext=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        notext.translation = geometry.center();
        no.add(notext);
        notext.castShadow=false;
        notext.visible=false;
        notext.position.set(0,0,0.3);
	});
	
}

function removelearning()
{
	plane.visible=false;
	yes.visible=false;
	no.visible=false;
	yestext.visible=false;
	notext.visible=false;
	t.visible=false;
	t2.visible=false;
	
	PIErender();
}

function answer()
{
	if(glass.visible==true&&wool.visible==true)
		ans=false;
	else if(wood.visible==true&&cotton.visible==true)
		ans=false;
	else
		ans=true;
	
	if(cotton.visible==true)
		ans=false;
}

function yesanswer()
{
	if(ans==true)
	{
		alert("Correct");
		progress=1;
	}
	else
		alert("Wrong");
}

function noanswer()
{
	if(ans==false)
	{
		alert("Correct");
		progress=1;
	}
	else
		alert("Wrong");
	
}

function learningthings()
{
	plane.visible=true;
	yes.visible=true;
	no.visible=true;
	yestext.visible=true;
	notext.visible=true;
	t.visible=true;
	t2.visible=true;
	
	PIEsetClick(yes, yesanswer);
	PIEsetClick(no, noanswer);
}

function learningmode()
{
	lm=1;
	
	progress=0;
	
	text.Learning_Mode=true;
	text.Experiment_Mode=false;
	PIEinputGUI.updateDisplay();
	
	f1.close();
	f2.close();
	
	document.getElementById("mytable2").style.visibility="visible";
	document.getElementById("mytable").style.visibility="hidden";
	
	var x=Math.round(Math.random()*4);
	var y=Math.round(Math.random()*4);
	
	if(x==0)
		rulerappears();
	if(x==1)
		eraserappears();
	if(x==2)
		woodappears();
	if(x==3)
		glassappears();
	if(y==0)
		woolappears();
	if(y==1)
		silkappears();
	if(y==2)
		hairappears();
	if(y==3)
		cottonappears();
	
	objecton();
	surfaceon();
	chargeset();
	appendtable2();
	
	answer();
	//learningthings();
	
	PIErender();
}

function experimentmode()
{
	
	lm=0;
	text.Learning_Mode=false;
	text.Experiment_Mode=true;
	PIEinputGUI.updateDisplay();
	f1.open();
	f2.open();
	
	removelearning();
	document.getElementById("mytable2").style.visibility="hidden";
	document.getElementById("mytable").style.visibility="visible";
	
}

function addRubbingsurfaces()
{
	wool=new THREE.Mesh(new THREE.CubeGeometry(10,0.4,6),new THREE.MeshBasicMaterial({map:THREE.ImageUtils.loadTexture("wool3.jpg")}));
	wool.rotation.x+=Math.PI/6;
	wool.position.set(4,-2.2,0);
	wool.visible=false;
	PIEaddElement(wool);
	
	hair=new THREE.Mesh(new THREE.CubeGeometry(10,0.4,6),new THREE.MeshBasicMaterial({map:THREE.ImageUtils.loadTexture("hair2.jpg")}));
	hair.rotation.x+=Math.PI/6;
	hair.position.set(4,-2.2,0);
	hair.visible=false;
	PIEaddElement(hair);
	
	silk=new THREE.Mesh(new THREE.CubeGeometry(10,0.4,6),new THREE.MeshBasicMaterial({map:THREE.ImageUtils.loadTexture("silk.jpg")}));
	silk.rotation.x+=Math.PI/6;
	silk.position.set(4,-2.2,0);
	silk.visible=false;
	PIEaddElement(silk);
	
	cotton=new THREE.Mesh(new THREE.CubeGeometry(10,0.4,6),new THREE.MeshBasicMaterial({map:THREE.ImageUtils.loadTexture("cotton.jpg")}));
	cotton.rotation.x+=Math.PI/6;
	cotton.position.set(4,-2.2,0);
	cotton.visible=false;
	PIEaddElement(cotton);
	
}

function addEverydaymaterial()
{
	ruler=new THREE.Mesh(new THREE.CubeGeometry(8,1.5,0.1),new THREE.MeshBasicMaterial({color:"white",transparent:true,opacity:0.5}));
	ruler.position.set(0,1,0);
	PIEaddElement(ruler);
	
	for(var i=-11;i<11.7;i+=0.30)
	{
		var line=new THREE.Mesh(new THREE.PlaneGeometry(0.01,0.5,2),new THREE.MeshBasicMaterial({color:"black"}));
		line.position.set(i/3,0.5,0);
		ruler.add(line);
	}
	
	for(var i=-11;i<13;i+=1.5)
	{
		var line=new THREE.Mesh(new THREE.PlaneGeometry(0.01,1,2),new THREE.MeshBasicMaterial({color:"black"}));
		line.position.set(i/3,0.26,0);
		ruler.add(line);
	}
	 ruler.rotation.z+=Math.PI/3;
	 ruler.rotation.x-=Math.PI/4;
	 
	 ruler.visible=false;
	 //PIEdragElement(ruler);
	 //PIEsetDrag(ruler,drag);
	 
	 wood=new THREE.Mesh(new THREE.CubeGeometry(8,1.2,1),new THREE.MeshBasicMaterial({map:THREE.ImageUtils.loadTexture("wood2.jpg")}));
	 wood.position.set(0,1.5,0);
	 PIEaddElement(wood);
	 wood.rotation.z+=Math.PI/3;
	 wood.rotation.x-=Math.PI/4;
	 wood.visible=false;
	 //PIEdragElement(wood);
	// PIEsetDrag(wood,drag);
	 
	 var geo=new THREE.CubeGeometry(3,1.3,0.6);
	 eraser=new THREE.Mesh(geo,new THREE.MeshBasicMaterial({map:THREE.ImageUtils.loadTexture("eraser.jpg")}));
	 eraser.position.set(0,0,0);
	 PIEaddElement(eraser);
	 eraser.rotation.z+=Math.PI/3;
	 eraser.rotation.x-=Math.PI/4;
	 eraser.visible=false;
	 //PIEdragElement(eraser);
	 //PIEsetDrag(eraser,drag);
	 var edges = new THREE.EdgesGeometry( geo );
	 var line = new THREE.LineSegments( edges, new THREE.LineBasicMaterial( { color: "grey",linewidth:0.1 } ) );
     eraser.add( line );
	 
	 
	 glass=new THREE.Mesh(new THREE.CylinderGeometry(0.5,0.5,8,100),new THREE.MeshBasicMaterial({map:THREE.ImageUtils.loadTexture("glass.jpg"),transparent:true,opacity:0.85}));
	 glass.position.set(0,1,0);
	 PIEaddElement(glass);
	 glass.rotation.z-=Math.PI/3;
	  //glass.rotation.x-=Math.PI/4;
	 glass.rotation.y+=Math.PI/6;
	 glass.visible=false;
	 //PIEdragElement(glass);
	// PIEsetDrag(glass,drag);
	 
	 var loader = new THREE.FontLoader();
    loader.load("optimer.json", function(response){
        font = response;
		
		geometry = new THREE.TextGeometry('+', {
        	font : font,
            size : 0.5,
            height : 0.02,
        });
		pe1=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        pe1.translation = geometry.center();
        eraser.add(pe1);
        pe1.castShadow=false;
        pe1.visible=false;
        pe1.position.set(-1,0,0.3);
		
		pe2=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        pe2.translation = geometry.center();
        eraser.add(pe2);
        pe2.castShadow=false;
        pe2.visible=false;
        pe2.position.set(-0.5,-0.3,0.3);
		
		pe3=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        pe3.translation = geometry.center();
        eraser.add(pe3);
        pe3.castShadow=false;
        pe3.visible=false;
        pe3.position.set(-0.5,0.3,0.3);
		
		
		
		pr1=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        pr1.translation = geometry.center();
        ruler.add(pr1);
        pr1.castShadow=false;
        pr1.visible=false;
        pr1.position.set(-3.8,0,0.3);
		
		pr2=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        pr2.translation = geometry.center();
        ruler.add(pr2);
        pr2.castShadow=false;
        pr2.visible=false;
        pr2.position.set(-3.3,0.3,0.3);
		
		pr3=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        pr3.translation = geometry.center();
        ruler.add(pr3);
        pr3.castShadow=false;
        pr3.visible=false;
        pr3.position.set(-3.3,-0.3,0.3);
		
		
		
		ps1=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        ps1.translation = geometry.center();
        glass.add(ps1);
        ps1.castShadow=false;
        ps1.visible=false;
        ps1.position.set(0,-3.8,0.5);
		
		ps2=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        ps2.translation = geometry.center();
        glass.add(ps2);
        ps2.castShadow=false;
        ps2.visible=false;
        ps2.position.set(0.15,-3.3,0.5);
		
		ps3=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        ps3.translation = geometry.center();
        glass.add(ps3);
        ps3.castShadow=false;
        ps3.visible=false;
        ps3.position.set(-0.38,-3.3,0.5);
		
		
		
		pw1=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        pw1.translation = geometry.center();
        wood.add(pw1);
        pw1.castShadow=false;
        pw1.visible=false;
        pw1.position.set(-3.8,0,0.6);
		
		pw2=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        pw2.translation = geometry.center();
        wood.add(pw2);
        pw2.castShadow=false;
        pw2.visible=false;
        pw2.position.set(-3.3,0.3,0.6);
		
		pw3=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        pw3.translation = geometry.center();
        wood.add(pw3);
        pw3.castShadow=false;
        pw3.visible=false;
        pw3.position.set(-3.3,-0.3,0.6);
	
		geometry = new THREE.TextGeometry('I', {
        	font : font,
            size : 0.4,
            height : 0.02,
        });
		
		ne1=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        ne1.translation = geometry.center();
        eraser.add(ne1);
        ne1.castShadow=false;
        ne1.visible=false;
        ne1.position.set(-1,0,0.3);
		
		ne2=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        ne2.translation = geometry.center();
        eraser.add(ne2);
        ne2.castShadow=false;
        ne2.visible=false;
        ne2.position.set(-0.5,-0.3,0.3);
		
		ne3=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        ne3.translation = geometry.center();
        eraser.add(ne3);
        ne3.castShadow=false;
        ne3.visible=false;
        ne3.position.set(-0.5,0.3,0.3);
		
		
		
		nr1=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        nr1.translation = geometry.center();
        ruler.add(nr1);
        nr1.castShadow=false;
        nr1.visible=false;
        nr1.position.set(-3.8,0,0.3);
		
		nr2=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        nr2.translation = geometry.center();
        ruler.add(nr2);
        nr2.castShadow=false;
        nr2.visible=false;
        nr2.position.set(-3.3,0.3,0.3);
		
		nr3=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        nr3.translation = geometry.center();
        ruler.add(nr3);
        nr3.castShadow=false;
        nr3.visible=false;
        nr3.position.set(-3.3,-0.3,0.3);
		
		
		
		ns1=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        ns1.translation = geometry.center();
        glass.add(ns1);
        ns1.castShadow=false;
        ns1.visible=false;
        ns1.position.set(0,-3.8,0.5);
		
		ns2=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        ns2.translation = geometry.center();
        glass.add(ns2);
        ns2.castShadow=false;
        ns2.visible=false;
        ns2.position.set(0.15,-3.3,0.5);
		
		ns3=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        ns3.translation = geometry.center();
        glass.add(ns3);
        ns3.castShadow=false;
        ns3.visible=false;
        ns3.position.set(-0.38,-3.3,0.5);
		
		
		
		nw1=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        nw1.translation = geometry.center();
        wood.add(nw1);
        nw1.castShadow=false;
        nw1.visible=false;
        nw1.position.set(-3.8,0,0.6);
		
		nw2=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        nw2.translation = geometry.center();
        wood.add(nw2);
        nw2.castShadow=false;
        nw2.visible=false;
        nw2.position.set(-3.3,0.3,0.6);
		
		nw3=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        nw3.translation = geometry.center();
        wood.add(nw3);
        nw3.castShadow=false;
        nw3.visible=false;
        nw3.position.set(-3.3,-0.3,0.6);
	});
}

function drag(element,newpos)
{
	element.position.x=newpos.x;	
}

function addPapers()
{
	for(var i=0;i<10;i++)
	{
		var temp=new THREE.Mesh(new THREE.CubeGeometry(0.5,0.05,0.5),new THREE.MeshBasicMaterial({color:"white"}));
		temp.rotation.x+=Math.PI/6;
		if(i==0)
		temp.position.set(-10,-2.2,0);
		if(i==1)
		temp.position.set(-8.2,-1.9,3);
		if(i==2)
		temp.position.set(-7.6,-2,3);	
		if(i==3)
		temp.position.set(-7,-1.9,3);
		if(i==4)
		temp.position.set(-6.3,-2,3);
		if(i==5)
		temp.position.set(-10,-1.7,0);	
		if(i==6)
		temp.position.set(-9.2,-1.5,0);		
		if(i==7)
		temp.position.set(-8.5,-1.8,0);	
		if(i==8)
		temp.position.set(-8,-1.45,0);	
		if(i==9)
		temp.position.set(-7.3,-1.5,0);	
		PIEaddElement(temp);
		temp.visible=true;
		p.push(temp);
	}
	
}

function rulerappears()
{
	
	text.Ruler=true;
	text.Eraser=false;
	text.Wood=false;
	text.Glass=false;
	PIEinputGUI.updateDisplay();
	
	ruler.visible=true;
	eraser.visible=false;
	wood.visible=false;
	glass.visible=false;
	
	PIErender();
}

function eraserappears()
{
	text.Ruler=false;
	text.Eraser=true;
	text.Wood=false;
	text.Glass=false;
	PIEinputGUI.updateDisplay();
	
	ruler.visible=false;
	eraser.visible=true;
	wood.visible=false;
	glass.visible=false;
	
	PIErender();
}

function woodappears()
{
	text.Ruler=false;
	text.Eraser=false;
	text.Wood=true;
	text.Glass=false;
	PIEinputGUI.updateDisplay();
	
	ruler.visible=false;
	eraser.visible=false;
	wood.visible=true;
	glass.visible=false;
	
	PIErender();
}

function glassappears()
{
	text.Ruler=false;
	text.Eraser=false;
	text.Wood=false;
	text.Glass=true;
	PIEinputGUI.updateDisplay();
	
	ruler.visible=false;
	eraser.visible=false;
	wood.visible=false;
	glass.visible=true;
	
	PIErender();
}

function woolappears()
{	
	text.Wool=true;
	text.Silk=false;
	text.Hair=false;
	text.Cotton=false;
	PIEinputGUI.updateDisplay();
	
	wool.visible=true;
	silk.visible=false;
	hair.visible=false;
	cotton.visible=false;
	
	PIErender();
}

function silkappears()
{
	text.Wool=false;
	text.Silk=true;
	text.Hair=false;
	text.Cotton=false;
	PIEinputGUI.updateDisplay();
	
	wool.visible=false;
	silk.visible=true;
	hair.visible=false;
	cotton.visible=false;
	
	PIErender();
}

function hairappears()
{
	text.Wool=false;
	text.Silk=false;
	text.Hair=true;
	text.Cotton=false;
	PIEinputGUI.updateDisplay();
	
	wool.visible=false;
	silk.visible=false;
	hair.visible=true;
	cotton.visible=false;
	
	PIErender();
}

function cottonappears()
{
	text.Wool=false;
	text.Silk=false;
	text.Hair=false;
	text.Cotton=true;
	PIEinputGUI.updateDisplay();
	
	wool.visible=false;
	silk.visible=false;
	hair.visible=false;
	cotton.visible=true;
	
	PIErender();
}

function objecton()
{
	if(ruler.visible==true)
	{
		object=ruler;
		k=-0.5;
		l=-0.5;
		p1=pr1;
		p2=pr2;
		p3=pr3;
		n1=nr1;
		n2=nr2;
		n3=nr3;
	}
	if(glass.visible==true)
	{
		object=glass;
		k=0;
		l=0;
		p1=ps1;
		p2=ps2;
		p3=ps3;
		n1=ns1;
		n2=ns2;
		n3=ns3;
	}
	if(wood.visible==true)
	{
		object=wood;
		k=-0.7;
		l=-0.5;
		p1=pw1;
		p2=pw2;
		p3=pw3;
		n1=nw1;
		n2=nw2;
		n3=nw3;
	}
	if(eraser.visible==true)
	{
		object=eraser;	
		k=-1.9;
		l=-2;
		p1=pe1;
		p2=pe2;
		p3=pe3;
		n1=ne1;
		n2=ne2;
		n3=ne3;
	}

	//object.position.x=2.5;
}

function surfaceon()
{
	if(hair.visible==true)
	surface=hair;
	if(silk.visible==true)
	surface=silk;
	if(wool.visible==true)
	surface=wool;
	if(cotton.visible==true)
	surface=cotton;	
}

function chargeset()
{
	if(ruler.visible==true||eraser.visible==true)
		charge=-1;
	
	if(glass.visible==true&&wool.visible==true)
		charge=0;
	else if(glass.visible==true)
		charge=1;
	
	if(wood.visible==true&&cotton.visible==true)
		charge=0;
	else if(wood.visible==true)
		charge=-1;
	
	if(cotton.visible==true)
		charge=0;
}

function resetpapers()
{
		p[0].position.set(-10,-2.2,0);
		p[1].position.set(-8.2,-1.9,3);
		p[2].position.set(-7.6,-2,3);	
		p[3].position.set(-7,-1.9,3);
		p[4].position.set(-6.3,-2,3);
		p[5].position.set(-10,-1.7,0);	
		p[6].position.set(-9.2,-1.5,0);	
		p[7].position.set(-8.5,-1.8,0);	
		p[8].position.set(-8,-1.45,0);
		p[9].position.set(-7.3,-1.5,0);	
		
		for(var i=0;i<10;i++)
		{
			p[i].rotation.x=Math.PI/6;
			p[i].rotation.y=0;
			p[i].rotation.z=0;
		}	
}

function resetcharges()
{
	p1.visible=false;
	p2.visible=false;
	p3.visible=false;
	n1.visible=false;
	n2.visible=false;
	n3.visible=false;
}

function resetposition()
{
	object.position.x=0;
}

function resetobject()
{
			if(object!=glass)
			{
				if(object==wood)
					object.position.y=1.5;
				object.rotation.z=Math.PI/3;
				object.rotation.x=-Math.PI/4;
			}
			else
			{
				object.rotation.z=-Math.PI/3;
				object.rotation.y=Math.PI/6;
				object.rotation.x=0;
			}
}

function empty()
{	
}

function addElementsToScene()
{
	addTable();
	addRubbingsurfaces();
	addEverydaymaterial();
	addlearning();
	addPapers();
	
	/*if(window.outerWidth<1600)
	{
		alert();
		//PIEtoggleTable();
		PIEtableSelect("Experimental Data");
		PIEtoggleTable(t1);
		PIEtableSelect("Experimental Data.");
		PIEtoggleTable(t2);
		//document.getElementById("mytable2").style.close();
		//document.getElementById("mytable").style.close();
	}*/
	
	PIErender();
}

function initialisescene()
{
	PIEscene.background = new THREE.Color( 0xADD8E6 );
	
	var light =new THREE.PointLight( 0xffff66 ,0.7,100);
	light.position.set(0,0,50);
	PIEaddElement(light);
	
}

function loadExperimentElements()
{

	initialiseHelp();
	initialiseInfo();
	initialisescene();
	addElementsToScene();
	
	PIEsetExperimentTitle("Experiment charging by rubbing");
    PIEsetDeveloperName("Aryaman");
	
	if(window.outerWidth<700&&window.outerWidth>600)
	{
		alert(window.outerWidth);
		var q=2.5;
		PIEsetAreaOfInterest(-12*q, 7*q/2.2,12*q,- 7*q/2.2);
	}
	else if(window.outerWidth<=600&&window.outerWidth>450)
	{
		alert(window.outerWidth);
		PIEsetAreaOfInterest(-12*2, 7*1.4,12*2,- 7*1.4);
	}
	else if(window.outerWidth<=450&&window.outerWidth>400)
	{
		alert(window.outerWidth);
		PIEsetAreaOfInterest(-12*4, 7*1.6,12*4,- 7*1.6);
	}
	else if(window.outerWidth<=400)
	{
		alert(window.outerWidth);
		PIEsetAreaOfInterest(-12*5, 7*1.9,12*5,- 7*1.9);
	}
	else
		PIEsetAreaOfInterest(-12, 7,12,- 7);
	
	//alert(window.outerWidth);
	/*PIEsetAreaOfInterest(-12, 7,12,- 7);
	PIErenderer.autoClear=false;*/
	
	
	PIEcreateTable("Experimental Data", 6, 3, true);
    var headerRow=["Everyday", "Rubbing", "Charge on"];
	PIEupdateTableRow(0, headerRow);
	var headerRow=["Material(A)","Material(B)","Material A"];
	PIEupdateTableRow(1,headerRow);
	
	PIEcreateTable1("Experimental Data.", 6, 2, true);
    var headerRow=["Everyday", "Rubbing"];
	PIEupdateTableRow(0, headerRow);
	var headerRow=["Material(A)","Material(B)"];
	PIEupdateTableRow(1,headerRow);
	
	document.getElementById("mytable2").style.visibility="hidden";
	
	/*PIEaddInputCommand("Everyday Material",empty);
	
	PIEaddInputCheckbox("Ruler", false, rulerappears);
	PIEaddInputCheckbox("Eraser", false, eraserappears);
	PIEaddInputCheckbox("Wood", false, woodappears);
	PIEaddInputCheckbox("Glass", false, glassappears);
	
	PIEaddInputCommand("Rubbing Material",empty);
	
	PIEaddInputCheckbox("Wool", false, woolappears);
	PIEaddInputCheckbox("Silk", false, silkappears);
	PIEaddInputCheckbox("Hair", false, hairappears);
	PIEaddInputCheckbox("Cotton", false, cottonappears);
	
	PIEaddInputCommand("Mode",empty);
	
	PIEaddInputCheckbox("Learning Mode", false, learningmode);
	PIEaddInputCheckbox("Experiment Mode", true, experimentmode);*/
		
	MyText = function() {
	  this.Ruler = false;
	  this.Eraser=false;
	  this.Wood=false;
	  this.Glass=false;
	  this.Wool=false;
	  this.Silk=false;
	  this.Hair=false;
	  this.Cotton=false;
	  this.Learning_Mode=false;
	  this.Experiment_Mode=true;
	  // Define render logic ...
	};
	
	text = new MyText();
	 
	PIEinputGUI.add(text,'Learning_Mode').onFinishChange(learningmode);
	PIEinputGUI.add(text,'Experiment_Mode').onFinishChange(experimentmode);
	
	f1 = PIEinputGUI.addFolder('Everyday Materials');
	f1.add(text, 'Ruler').onFinishChange(rulerappears);
	f1.add(text, 'Eraser').onFinishChange(eraserappears);
	f1.add(text, 'Wood').onFinishChange(woodappears);
	f1.add(text, 'Glass').onFinishChange(glassappears);
	
	f2 = PIEinputGUI.addFolder('Rubbing Materials');
	f2.add(text, 'Wool').onFinishChange(woolappears);
	f2.add(text, 'Silk').onFinishChange(silkappears);
	f2.add(text, 'Hair').onFinishChange(hairappears);
	f2.add(text, 'Cotton').onFinishChange(cottonappears);

	f1.open();
	f2.open();
	
	/*text.Learning_Mode=true;
	PIEinputGUI.updateDisplay();*/
	
	rulerappears();
	silkappears();
	resettable();
	
	tableindex=2;
	count=0;
	lm=0;
	progress=0;
}

function PIEstartAnimation()
{
	if(PIEanimationON==false){PIElastUpdateTime=Date.now();PIEpauseOffset=0;PIEcurrentTime=0;PIEoffsetTime=0;PIEanimationON=true;PIEanimationPaused=false;PIEresumeButton.style.display="none";PIEresumeButton.style.visibility="hidden";PIEpauseButton.style.display="inline";PIEpauseButton.style.visibility="visible";PIEstartButton.style.display="none";PIEstopButton.style.display="inline";PIEshowDisplayPanel();PIEanimate()}
	
	
	if(lm==0)
	{
		experimentmode();
		objecton();
		surfaceon();
		chargeset();
		appendtable();
	}
	else
	{
		learningthings();
	}
	
	check=0;
	count=0;
}

function PIEstopAnimation()
{
	if(PIEanimationON==true){PIEpauseOffset=0;PIEcurrentTime=0;PIEoffsetTime=0;PIEanimationON=false;PIEanimationPaused=false;PIEresumeButton.style.display="none";PIEresumeButton.style.visibility="hidden";PIEpauseButton.style.display="inline";PIEpauseButton.style.visibility="hidden";PIEstopButton.style.display="none";PIEstartButton.style.display="inline";PIEshowInputPanel()}
	resetpapers();
	resetcharges();
	resetposition();
	resetobject();
	
	PIErender();
}

function resetExperiment()
{
	resetpapers();
	resetcharges();
	resetposition();
	glassappears();
	hairappears();
	resettable();
	experimentmode();
	
	lm=0;
	tableindex=2;
	count=0;
	PIErender();
}

function updateExperimentElements(t, dt) 
{  

	if(object&&((lm==1&&progress==1)||lm==0))
	{
		if(progress==1&&lm==1)
			removelearning();
		if(object.position.x>1.5)
		{
			if(object!=glass)
			{
				if(object==wood)
					object.position.y=0.8;
				object.rotation.z=Math.PI/2;
				object.rotation.x=-Math.PI/3;
			}
			else
			{
				object.rotation.z=0;
				object.rotation.x=-Math.PI/3;
			}
			//object.rotation.y=0;
		}
		else if(object.position.x<1.5)
		{
			if(object!=glass)
			{
				if(object==wood)
					object.position.y=1.5;
				object.rotation.z=Math.PI/3;
				object.rotation.x=-Math.PI/4;
			}
			else
			{
				object.rotation.z=-Math.PI/3;
				object.rotation.y=Math.PI/6;
				object.rotation.x=0;
			}
			//object.rotation.y=0;
		}
		
		if(count<8)
		{
			if(object.position.x<6&&check==0)
			{
				object.position.x+=0.2;
			}
			else if(check==0)
			{
				check=1;
			}
			
			if(object.position.x>2&&check==1)
			{
				//while(object.position.x>0)
				object.position.x-=0.2;
			
			}
			else if(check==1)
			{
				check=0;
				count++;
			}
			if(count==2)
			{
				if(charge==1)
					p1.visible=true;
				if(charge==-1)
					n1.visible=true;
			}
			if(count==4)
			{
				if(charge==1)
					p2.visible=true;
				if(charge==-1)
					n2.visible=true;
			}
			if(count==6)
			{
				if(charge==1)
					p3.visible=true;
				if(charge==-1)
					n3.visible=true;
			}
		}
		else 
		{	
			if(object.position.x>-5+l)
				object.position.x-=0.1;
			//paper code
			
			if(charge!=0)
			{
				if(object.position.x<-5+l+0.5)
				{
						//object.position.x=-5+l;
					if(p[1].position.y<-0.8)
						p[1].position.y+=0.02;
					if(p[1].rotation.x>-Math.PI/6)
						p[1].rotation.x-=Math.PI/200;
					if(p[1].rotation.y<Math.PI/6)
						p[1].rotation.y+=Math.PI/200;
					if(p[1].position.x<-7.7)
						p[1].position.x+=0.02;
					
					if(p[2].position.y<-1.1)
						p[2].position.y+=0.02;
					if(p[2].rotation.x>-Math.PI/6)
						p[2].rotation.x-=Math.PI/200;
					
					if(p[6].position.y<-1)
						p[6].position.y+=0.02;
					if(p[6].rotation.x<Math.PI/3)
						p[6].rotation.x+=Math.PI/200;
					if(p[6].position.x<-8.5)
						p[6].position.x+=0.02;
					
					if(p[7].position.y<-1.3)
						p[7].position.y+=0.02;
					if(p[7].rotation.x<Math.PI/3)
						p[7].rotation.x+=Math.PI/200;
					if(p[7].position.x<-8.4)
						p[7].position.x+=0.02;
				}
				
				if(object.position.x<-5+l+2)
				{
					if(p[3].position.y<-1.3)
						p[3].position.y+=0.02;
					if(p[3].position.x>-7.4)
						p[3].position.x-=0.02;
					
					
					if(p[8].position.y<-1)
						p[8].position.y+=0.02;
					if(p[8].rotation.x<Math.PI/6)
						p[8].rotation.x+=Math.PI/200;
				}
				if(object.position.x<-5+l+3.5)	
				{	
					if(p[9].position.x>-8)
						p[9].position.x-=0.02;
					if(p[9].position.y<-1)
						p[9].position.y+=0.02;
					if(p[9].rotation.x<Math.PI/6)
						p[9].rotation.x+=Math.PI/200;
					
					if(p[4].position.y<-1.2)
						p[4].position.y+=0.02;
					if(p[4].position.x>-7)
						p[4].position.x-=0.02;
					if(p[4].rotation.x<Math.PI/3)
						p[4].rotation.x+=Math.PI/200;
				}
			}
		}
	}
}